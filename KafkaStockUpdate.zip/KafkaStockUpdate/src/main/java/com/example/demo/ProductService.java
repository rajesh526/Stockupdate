package com.example.demo;

import java.io.IOException;
import java.sql.Blob;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.List;

import org.json.JSONException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.stereotype.Service;

@Service
public class ProductService {
	@Autowired  
	JdbcTemplate jdbctemplate;
	
	

	public List<FurnitureStock> getAll(){
	
		
		String sql2="select*from stock";
		RowMapper<FurnitureStock> rm = new RowMapper<FurnitureStock>() {
            @Override
			public FurnitureStock mapRow(ResultSet rs, int rowNum) throws SQLException {
            	FurnitureStock res1 = new FurnitureStock();
            	
 					res1.setId(rs.getString(1));
 					res1.setProductname(rs.getString(2));
 	                res1.setProductimage(rs.getBlob(3));
 	           	    res1.setProductcost(rs.getInt(4));
 	           	    res1.setProductquantity(rs.getInt(5));
                return res1;
            
			}   
        };
      
		return  jdbctemplate.query(sql2, rm);
		}
	
	public Blob getPhotoByName(String productname) throws SQLException, IOException, JSONException {
	
		String query = "select pimage from where where pname= ?";
		Blob photo = jdbctemplate.queryForObject(query,new Object[] {productname},  Blob.class);   
		return photo;
	}
	
}


