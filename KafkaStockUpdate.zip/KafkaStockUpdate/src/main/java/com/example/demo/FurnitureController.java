package com.example.demo;

import java.io.ByteArrayInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.sql.Blob;
import java.sql.SQLException;
import java.sql.Types;

import javax.servlet.http.HttpServletResponse;

import org.apache.commons.io.IOUtils;
import org.json.JSONException;
import org.springframework.asm.Type;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.support.SqlLobValue;
import org.springframework.jdbc.support.lob.DefaultLobHandler;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.multipart.MultipartFile;

@Controller
public class FurnitureController {
	@Autowired
	JdbcTemplate jdbctemplate;
	@Autowired
	ProductService service;
	
	@RequestMapping("/")
	public String index() {
		return "index";
		
	}
	@RequestMapping("/stock")
	public String stock() {
		return "Stock";
	}
	@RequestMapping(value="/upload" ,method=RequestMethod.POST)
	public String Upload(@RequestParam String id,@RequestParam String productname,@RequestParam MultipartFile productimage, @RequestParam int productcost,@RequestParam int productquantity,Model model) throws IOException {
		
		 String s= "select count(*) name from stock where pname=?";
		 int count =jdbctemplate.queryForObject(s,new  Object[] {productname},Integer.class);
		 String s1 ="insert into stock (id,pname,pimage,pcost,pquantity) values (?,?,?,?,?)";
		 byte[] data=productimage.getBytes();
			
		    if (count ==0) {
               jdbctemplate.update(s1,new Object[] {productname, new SqlLobValue(new ByteArrayInputStream(data), data.length, new DefaultLobHandler())},new int[] {Types.VARCHAR,Types.BLOB,Types.INTEGER});
			   return "index";
			}
		   else {
			model.addAttribute("FileName", "FileName");
			return "stock";
			
		}	
	}
	
	//To get All results form database
	@RequestMapping(value="/get",method=RequestMethod.GET)
	public String ImageResults(Model model) {
		
		model.addAttribute("results", service.getAll());   
               
		return "stockresult";
		
	}
	
	
	@RequestMapping(value="/get/{productname}" )
	@ResponseBody
	
	public void Result(HttpServletResponse response ,Model model,@PathVariable("productname") String productname)  throws IOException, SQLException, JSONException {
		response.setContentType("image/jpeg,image/jpg,image/png,image/gif,image/jfif");
		
      
        Blob blob =service.getPhotoByName( productname) ;
        byte[] bytes = blob.getBytes(1, (int)blob.length());
		InputStream inputStream = new ByteArrayInputStream(bytes); 
		IOUtils.copy(inputStream, response.getOutputStream());
      
              }
	

}
